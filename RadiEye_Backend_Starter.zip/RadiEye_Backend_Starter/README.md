# RadiEye Anatomy — Backend starter

This is the first Next.js + Supabase integration scaffold. It includes:
- Supabase browser/server clients and session-refresh middleware
- Email/password signup, login, email confirmation callback and sign-out
- A protected dashboard reading profile, bookmarks and learning progress
- A reviewed initial database migration with RLS and role-escalation protection

## Setup
1. Use Node.js 20.9+.
2. Copy `.env.example` to `.env.local` and fill in the Supabase **Project URL** and **publishable/anon key**.
3. In Supabase SQL Editor, run `supabase/migrations/0001_radiEye_schema.sql` on a fresh project (or review and adapt it if tables already exist).
4. In Supabase Authentication > URL Configuration, set Site URL to your local/deployed origin and add `http://localhost:3000/auth/callback` plus the deployed `/auth/callback` URL to Redirect URLs.
5. Run `npm install`, then `npm run dev`.

## Security
- Never share or place the `service_role` / secret key in frontend code, `.env` variables prefixed with `NEXT_PUBLIC_`, or chat.
- Only the publishable/anon key belongs in this starter's public environment variable.
- The first admin role must be assigned manually in the SQL editor after verifying the user's Auth UUID.
- Test RLS with separate anonymous, member, editor and admin accounts before production.

## Current scope / known next work
This scaffold is not yet a production release. It does not yet include the full redesigned UI, admin/editor content CRUD, media uploads, password reset, OAuth, email templates, audit log, rate limiting, analytics or deployment. The current dashboard lists record IDs pending content detail routes and polished components.
