-- RadiEye Anatomy initial schema. Review in staging before production.
create extension if not exists pgcrypto;
do $$ begin create type public.app_role as enum ('member','editor','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.content_status as enum ('draft','in_review','published','archived'); exception when duplicate_object then null; end $$;
do $$ begin create type public.content_kind as enum ('lesson','article','case','learning_path'); exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 role public.app_role not null default 'member',
 preferred_language text not null default 'ar' check (preferred_language in ('ar','en')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.categories (
 id uuid primary key default gen_random_uuid(), slug text not null unique,
 title_ar text not null, title_en text not null, description_ar text, description_en text,
 sort_order integer not null default 0, created_at timestamptz not null default now()
);
create table if not exists public.content_items (
 id uuid primary key default gen_random_uuid(), category_id uuid references public.categories(id) on delete set null,
 author_id uuid references public.profiles(id) on delete set null,
 kind public.content_kind not null default 'lesson', status public.content_status not null default 'draft',
 slug text not null unique, title_ar text not null, title_en text not null, summary_ar text, summary_en text,
 body_ar jsonb not null default '[]'::jsonb, body_en jsonb not null default '[]'::jsonb,
 level text not null default 'beginner' check (level in ('beginner','intermediate','advanced')),
 estimated_minutes integer check (estimated_minutes is null or estimated_minutes > 0),
 reviewed_by uuid references public.profiles(id) on delete set null, reviewed_at timestamptz, published_at timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.media_assets (
 id uuid primary key default gen_random_uuid(), content_id uuid references public.content_items(id) on delete cascade,
 storage_path text not null unique, alt_ar text, alt_en text, caption_ar text, caption_en text,
 source_name text, source_url text, license_name text, license_url text,
 rights_verified boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.learning_path_items (
 path_id uuid not null references public.content_items(id) on delete cascade,
 lesson_id uuid not null references public.content_items(id) on delete cascade,
 sort_order integer not null default 0, primary key(path_id,lesson_id), check(path_id<>lesson_id)
);
create table if not exists public.member_progress (
 member_id uuid not null references public.profiles(id) on delete cascade,
 content_id uuid not null references public.content_items(id) on delete cascade,
 completed boolean not null default false, completed_at timestamptz, last_position jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now(), primary key(member_id,content_id)
);
create table if not exists public.bookmarks (
 member_id uuid not null references public.profiles(id) on delete cascade,
 content_id uuid not null references public.content_items(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(member_id,content_id)
);
create table if not exists public.content_reviews (
 id uuid primary key default gen_random_uuid(), content_id uuid not null references public.content_items(id) on delete cascade,
 reviewer_id uuid not null references public.profiles(id) on delete cascade,
 decision text not null check(decision in ('approved','changes_requested','rejected')),
 notes text, created_at timestamptz not null default now()
);

create or replace function public.current_app_role() returns public.app_role
language sql stable security definer set search_path=public,pg_temp
as $$ select role from public.profiles where id=auth.uid(); $$;
create or replace function public.is_editor_or_admin() returns boolean
language sql stable security definer set search_path=public,pg_temp
as $$ select coalesce(public.current_app_role() in ('editor','admin'),false); $$;
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public,pg_temp
as $$ select coalesce(public.current_app_role()='admin',false); $$;
revoke all on function public.current_app_role() from public;
revoke all on function public.is_editor_or_admin() from public;
revoke all on function public.is_admin() from public;
grant execute on function public.current_app_role() to anon, authenticated;
grant execute on function public.is_editor_or_admin() to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
begin
 insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'display_name','')) on conflict(id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Prevent users from changing their own role, including through crafted API requests.
create or replace function public.protect_profile_role() returns trigger
language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if new.role is distinct from old.role and not public.is_admin() then
   raise exception 'Only an administrator can change account roles';
 end if;
 new.updated_at := now();
 return new;
end; $$;
drop trigger if exists protect_profile_role_trigger on public.profiles;
create trigger protect_profile_role_trigger before update on public.profiles for each row execute procedure public.protect_profile_role();

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.content_items enable row level security;
alter table public.media_assets enable row level security;
alter table public.learning_path_items enable row level security;
alter table public.member_progress enable row level security;
alter table public.bookmarks enable row level security;
alter table public.content_reviews enable row level security;

drop policy if exists profile_read_self_or_admin on public.profiles;
create policy profile_read_self_or_admin on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
drop policy if exists profile_update_self on public.profiles;
create policy profile_update_self on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
-- Column-level grants prevent role edits through PostgREST; service/admin SQL remains available.
revoke update on public.profiles from anon, authenticated;
grant update(display_name,preferred_language) on public.profiles to authenticated;

drop policy if exists categories_read_public on public.categories;
create policy categories_read_public on public.categories for select using(true);
drop policy if exists categories_manage_editor on public.categories;
create policy categories_manage_editor on public.categories for all to authenticated using(public.is_editor_or_admin()) with check(public.is_editor_or_admin());

drop policy if exists content_read_published_or_staff on public.content_items;
create policy content_read_published_or_staff on public.content_items for select using(status='published' or public.is_editor_or_admin());
drop policy if exists content_insert_staff on public.content_items;
create policy content_insert_staff on public.content_items for insert to authenticated with check(public.is_editor_or_admin());
drop policy if exists content_update_staff on public.content_items;
create policy content_update_staff on public.content_items for update to authenticated using(public.is_editor_or_admin()) with check(public.is_editor_or_admin());
drop policy if exists content_delete_admin on public.content_items;
create policy content_delete_admin on public.content_items for delete to authenticated using(public.is_admin());

drop policy if exists media_read_published_parent on public.media_assets;
create policy media_read_published_parent on public.media_assets for select using(exists(select 1 from public.content_items c where c.id=content_id and (c.status='published' or public.is_editor_or_admin())));
drop policy if exists media_manage_staff on public.media_assets;
create policy media_manage_staff on public.media_assets for all to authenticated using(public.is_editor_or_admin()) with check(public.is_editor_or_admin());

drop policy if exists path_items_read_published_parent on public.learning_path_items;
create policy path_items_read_published_parent on public.learning_path_items for select using(exists(select 1 from public.content_items c where c.id=path_id and (c.status='published' or public.is_editor_or_admin())));
drop policy if exists path_items_manage_staff on public.learning_path_items;
create policy path_items_manage_staff on public.learning_path_items for all to authenticated using(public.is_editor_or_admin()) with check(public.is_editor_or_admin());

drop policy if exists progress_read_self on public.member_progress;
create policy progress_read_self on public.member_progress for select to authenticated using(member_id=auth.uid());
drop policy if exists progress_insert_self on public.member_progress;
create policy progress_insert_self on public.member_progress for insert to authenticated with check(member_id=auth.uid());
drop policy if exists progress_update_self on public.member_progress;
create policy progress_update_self on public.member_progress for update to authenticated using(member_id=auth.uid()) with check(member_id=auth.uid());
drop policy if exists bookmarks_self_all on public.bookmarks;
create policy bookmarks_self_all on public.bookmarks for all to authenticated using(member_id=auth.uid()) with check(member_id=auth.uid());
drop policy if exists reviews_read_staff on public.content_reviews;
create policy reviews_read_staff on public.content_reviews for select to authenticated using(public.is_editor_or_admin());
drop policy if exists reviews_insert_staff on public.content_reviews;
create policy reviews_insert_staff on public.content_reviews for insert to authenticated with check(public.is_editor_or_admin() and reviewer_id=auth.uid());

create index if not exists content_items_status_idx on public.content_items(status);
create index if not exists content_items_category_idx on public.content_items(category_id);
create index if not exists content_items_published_idx on public.content_items(published_at desc) where status='published';
create index if not exists media_assets_content_idx on public.media_assets(content_id);
create index if not exists reviews_content_idx on public.content_reviews(content_id,created_at desc);
create index if not exists progress_member_updated_idx on public.member_progress(member_id,updated_at desc);

-- Explicit API privileges; RLS policies remain the row-level gate.
grant select on public.categories, public.content_items, public.media_assets, public.learning_path_items to anon, authenticated;
grant select, update(display_name,preferred_language) on public.profiles to authenticated;
grant select, insert, update, delete on public.member_progress, public.bookmarks to authenticated;
grant select, insert on public.content_reviews to authenticated;
grant insert, update, delete on public.categories, public.content_items, public.media_assets, public.learning_path_items to authenticated;

-- Promote the first verified administrator manually after signup:
-- update public.profiles set role='admin' where id='AUTH_USER_UUID';
