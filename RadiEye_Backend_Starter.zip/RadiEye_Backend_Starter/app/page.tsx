import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return <main style={{maxWidth:900,margin:'12vh auto',padding:24}}><p style={{letterSpacing:3,color:'#658071'}}>RADIEYE ANATOMY</p><h1>Learn anatomy through medical imaging.</h1><p>A connected learning platform for anatomy, radiology and clinical correlation.</p>{user ? <Link href="/dashboard">Open dashboard</Link> : <><Link href="/login">Log in</Link>　<Link href="/signup">Create account</Link></>}</main>;
}
