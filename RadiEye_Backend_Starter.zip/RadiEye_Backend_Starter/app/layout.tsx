import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'RadiEye Anatomy', description: 'Anatomy and medical imaging learning platform' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body style={{margin:0,fontFamily:'Arial, sans-serif',background:'#f5f5f0',color:'#202824'}}>{children}</body></html>;
}
