'use client';
import { FormEvent, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
export default function LoginPage() {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [message,setMessage]=useState(''); const [busy,setBusy]=useState(false);
  async function submit(e:FormEvent){e.preventDefault();setBusy(true);setMessage('');try{const {error}=await createClient().auth.signInWithPassword({email,password});if(error)throw error;window.location.assign('/dashboard');}catch(err){setMessage(err instanceof Error?err.message:'Login failed');}finally{setBusy(false);}}
  return <main style={{maxWidth:420,margin:'10vh auto',padding:24}}><h1>Log in</h1><form onSubmit={submit}><label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} style={field}/></label><label>Password<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} style={field}/></label><button disabled={busy} style={button}>{busy?'Please wait…':'Log in'}</button></form><p aria-live="polite">{message}</p></main>;
}
const field={display:'block',width:'100%',padding:12,margin:'8px 0 18px',boxSizing:'border-box' as const}; const button={padding:'12px 18px',border:0,borderRadius:8,background:'#527563',color:'white',cursor:'pointer'};
